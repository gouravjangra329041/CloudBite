# CloudBite 🍳 — Cloud Kitchen App

A cloud kitchen ordering app (eMentora internship project) built with **React Native + Expo**,
previewed with **Expo Go**. Two sides in one app:

- **Customer** — browse the menu, build a cart, checkout, and track the order live
- **Kitchen** — see the incoming order queue, advance order status, mark items sold out

## Features
| Area | What's included |
|---|---|
| Menu | Category chips + search, veg/non-veg marks, prices, prep time, spice level, sold-out states |
| Cart | Quantity steppers, bill summary (subtotal, GST 5%, delivery fee, free delivery over Rs.500) |
| Checkout | Name + address, order placed into the kitchen queue (demo — no real payment) |
| Order tracking | Live status timeline: Placed -> Accepted -> Preparing -> Ready -> Out for delivery -> Delivered, with timestamps and ETA |
| Kitchen mode | Order queue with items & totals, "Mark as <next status>" control, auto-progress demo toggle |
| Availability | Toggle any dish sold out — customers see it greyed out instantly |
| Persistence | Cart, orders and availability survive app restarts (AsyncStorage) |

## Architecture note (good for the viva)
An order is modeled as a **state machine** — a single ordered list of statuses with a
timestamped timeline. The customer's tracking screen and the kitchen's queue are two
views of the same state, so they can never disagree. In demo mode a timer advances
orders automatically every ~25 s; the kitchen can switch that off and drive statuses
manually.

## Setup (from zero)

1. **Install Node.js** (LTS) from nodejs.org if you don't have it.

2. **Create the Expo project:**
   ```bash
   npx create-expo-app@latest cloudbite --template blank
   cd cloudbite
   ```

3. **Install dependencies:**
   ```bash
   npx expo install @react-native-async-storage/async-storage react-native-screens react-native-safe-area-context
   npm install @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs
   ```

4. **Copy this project's files** into the created folder:
   - Replace `App.js` with the one from this zip
   - Copy the whole `src/` folder into the project root

5. **Run it:**
   ```bash
   npx expo start
   ```
   Scan the QR with **Expo Go** (same Wi-Fi). Order something from the Menu,
   then open the Kitchen tab and manage it.

## Where things live
```
App.js                       -> 4-tab navigation + cart badge
src/theme.js                 -> "midnight kitchen" design tokens
src/data/menu.js             -> menu catalog + GST/delivery config (edit freely)
src/context/KitchenContext.js-> cart, billing, order state machine, persistence
src/components/ui.js         -> VegMark, Stepper, Timeline, StatusPill, buttons, chips
src/screens/                 -> Menu, Cart, Orders, Kitchen
```

## Next steps (future scope)
- Real backend (Supabase) so customer and kitchen run on **separate devices** in realtime
- Payment gateway integration (Razorpay/UPI) for real checkout
- Push notification when the order goes out for delivery
- Delivery partner tracking on a map
- Ratings & reviews per dish
