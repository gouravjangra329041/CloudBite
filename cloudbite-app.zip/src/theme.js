// CloudBite — design tokens
// Identity: "midnight kitchen" — warm charcoal surfaces with tomato-red heat
// and saffron accents; food apps should feel appetizing, not clinical.

export const colors = {
  bg: '#FBF7F2',        // warm flour-white background
  surface: '#FFFFFF',
  ink: '#241A14',       // espresso text
  muted: '#8A7A6E',
  line: '#EDE4DB',
  primary: '#C4482A',   // tomato — buttons, active states
  primarySoft: '#F9E4DD',
  accent: '#E8A13C',    // saffron — highlights, ratings
  accentSoft: '#FBEFD9',
  dark: '#241A14',      // kitchen-mode header
  success: '#2E7D4F',
  veg: '#2E7D4F',
  nonveg: '#B03A2E',
};

export const spacing = { xs: 4, s: 8, m: 16, l: 24, xl: 32 };
export const radius = { s: 8, m: 14, l: 20, pill: 999 };

export const type = {
  h1: { fontSize: 24, fontWeight: '800', color: colors.ink, letterSpacing: -0.5 },
  h2: { fontSize: 19, fontWeight: '800', color: colors.ink, letterSpacing: -0.3 },
  h3: { fontSize: 15, fontWeight: '700', color: colors.ink },
  body: { fontSize: 14, color: colors.ink, lineHeight: 20 },
  small: { fontSize: 12, color: colors.muted },
  label: { fontSize: 11, fontWeight: '700', color: colors.muted, textTransform: 'uppercase', letterSpacing: 1 },
};
