import React, { useMemo, useState } from 'react';
import { View, Text, FlatList, TextInput, StyleSheet } from 'react-native';
import { MENU, CATEGORIES } from '../data/menu';
import { useKitchen } from '../context/KitchenContext';
import { VegMark, SpiceMeter, Stepper, Chip } from '../components/ui';
import { colors, spacing, radius, type } from '../theme';

export default function MenuScreen() {
  const { cart, add, remove, isSoldOut } = useKitchen();
  const [cat, setCat] = useState('All');
  const [query, setQuery] = useState('');

  const items = useMemo(
    () =>
      MENU.filter((m) => {
        const okCat = cat === 'All' || m.cat === cat;
        const q = query.trim().toLowerCase();
        return okCat && (!q || m.name.toLowerCase().includes(q) || m.cat.toLowerCase().includes(q));
      }),
    [cat, query]
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      {/* Brand header */}
      <View style={s.header}>
        <Text style={s.brand}>Cloud<Text style={{ color: colors.accent }}>Bite</Text> 🍳</Text>
        <Text style={s.tag}>Hot from our kitchen to your door</Text>
      </View>

      <View style={{ padding: spacing.m, paddingBottom: 0 }}>
        <TextInput
          style={s.search}
          placeholder="Search dishes…"
          placeholderTextColor={colors.muted}
          value={query}
          onChangeText={setQuery}
        />
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={CATEGORIES}
          keyExtractor={(c) => c}
          style={{ marginTop: spacing.m, flexGrow: 0 }}
          renderItem={({ item }) => <Chip label={item} active={cat === item} onPress={() => setCat(item)} />}
        />
      </View>

      <FlatList
        data={items}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: spacing.m, paddingBottom: 30 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const sold = isSoldOut(item.id);
          return (
            <View style={[s.card, sold && { opacity: 0.55 }]}>
              <View style={s.emojiTile}>
                <Text style={{ fontSize: 34 }}>{item.emoji}</Text>
              </View>
              <View style={{ flex: 1, gap: 3 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <VegMark veg={item.veg} />
                  <Text style={[type.h3, { flex: 1 }]} numberOfLines={2}>{item.name}</Text>
                </View>
                <Text style={type.small} numberOfLines={2}>{item.desc}</Text>
                <View style={s.metaRow}>
                  <Text style={s.price}>₹{item.price}</Text>
                  <Text style={type.small}>⏱ {item.prepMins} min</Text>
                  <SpiceMeter level={item.spice} />
                </View>
                <View style={{ alignSelf: 'flex-start', marginTop: 4 }}>
                  <Stepper
                    qty={cart[item.id] ?? 0}
                    onAdd={() => add(item.id)}
                    onRemove={() => remove(item.id)}
                    disabled={sold}
                  />
                </View>
              </View>
            </View>
          );
        }}
      />
    </View>
  );
}

const s = StyleSheet.create({
  header: {
    backgroundColor: colors.dark, paddingTop: 56, paddingBottom: spacing.m, paddingHorizontal: spacing.m,
  },
  brand: { fontSize: 26, fontWeight: '800', color: '#fff', letterSpacing: -0.5 },
  tag: { color: '#C7B8AC', fontSize: 12.5, marginTop: 2 },
  search: {
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line,
    borderRadius: radius.m, padding: 13, fontSize: 15, color: colors.ink,
  },
  card: {
    flexDirection: 'row', gap: spacing.m, backgroundColor: colors.surface,
    borderRadius: radius.m, borderWidth: 1, borderColor: colors.line,
    padding: spacing.m, marginBottom: spacing.m,
  },
  emojiTile: {
    width: 64, height: 64, borderRadius: radius.m, backgroundColor: colors.accentSoft,
    alignItems: 'center', justifyContent: 'center',
  },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 2 },
  price: { fontSize: 15, fontWeight: '800', color: colors.ink },
});
