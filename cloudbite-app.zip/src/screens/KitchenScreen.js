import React, { useState } from 'react';
import { View, Text, ScrollView, Switch, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { useKitchen, STATUSES } from '../context/KitchenContext';
import { MENU } from '../data/menu';
import { StatusPill, VegMark, PrimaryButton } from '../components/ui';
import { colors, spacing, radius, type } from '../theme';

// ---------------------------------------------------------------
// Owner-only area. Order-status control and menu availability are
// business operations — customers can browse, order and track, but
// only the kitchen owner (PIN) can move an order through its states.
// ---------------------------------------------------------------

function OwnerLock() {
  const { unlockOwner } = useKitchen();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const tryUnlock = () => {
    const ok = unlockOwner(pin.trim());
    if (!ok) {
      setError(true);
      setPin('');
    }
  };

  return (
    <View style={s.lockWrap}>
      <Text style={{ fontSize: 52 }}>🔐</Text>
      <Text style={[type.h1, { marginTop: spacing.s }]}>Owner access</Text>
      <Text style={[type.small, { textAlign: 'center', marginTop: 4, lineHeight: 18 }]}>
        Managing orders and menu availability is restricted to the kitchen owner.
        Customers can browse, order and track — but not change order status.
      </Text>
      <TextInput
        style={[s.pinInput, error && { borderColor: colors.nonveg }]}
        placeholder="Enter owner PIN"
        placeholderTextColor={colors.muted}
        keyboardType="number-pad"
        secureTextEntry
        maxLength={6}
        value={pin}
        onChangeText={(v) => { setPin(v); setError(false); }}
      />
      {error && <Text style={{ color: colors.nonveg, fontSize: 12.5, fontWeight: '700' }}>Incorrect PIN — try again.</Text>}
      <PrimaryButton title="Unlock kitchen" onPress={tryUnlock} style={{ alignSelf: 'stretch', marginTop: spacing.s }} />
      <Text style={[type.small, { marginTop: spacing.m }]}>Demo PIN: 1234</Text>
    </View>
  );
}

export default function KitchenScreen() {
  const { orders, advanceOrder, autoMode, setAutoMode, isSoldOut, toggleSoldOut, ownerMode, lockOwner } = useKitchen();

  if (!ownerMode) return <OwnerLock />;

  const active = orders.filter((o) => o.status !== 'Delivered');
  const done = orders.filter((o) => o.status === 'Delivered');

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ paddingBottom: 40 }}>
      {/* Owner header */}
      <View style={s.header}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={s.headTitle}>👨‍🍳 Kitchen — Owner Mode</Text>
          <TouchableOpacity onPress={lockOwner} style={s.lockBtn}>
            <Text style={{ color: '#C7B8AC', fontSize: 11.5, fontWeight: '700' }}>🔒 Lock</Text>
          </TouchableOpacity>
        </View>
        <Text style={s.headSub}>
          {active.length} active order{active.length === 1 ? '' : 's'} · {done.length} delivered
        </Text>
        <View style={s.autoRow}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#C7B8AC', fontSize: 12.5, fontWeight: '700' }}>Demo auto-progress</Text>
            <Text style={{ color: '#8A7A6E', fontSize: 10.5 }}>
              OFF by default — you control every status. Turn on only for hands-free demos.
            </Text>
          </View>
          <Switch
            value={autoMode}
            onValueChange={setAutoMode}
            trackColor={{ false: '#4A3C32', true: '#7A4A2E' }}
            thumbColor={autoMode ? colors.accent : '#8A7A6E'}
          />
        </View>
      </View>

      <View style={{ padding: spacing.m }}>
        {/* ---- Order queue ---- */}
        <Text style={type.h2}>Order queue</Text>
        {active.length === 0 && (
          <Text style={[type.small, { marginTop: spacing.s }]}>
            No active orders. New orders from customers arrive here with status "Placed".
          </Text>
        )}
        {active.map((o) => {
          const idx = STATUSES.indexOf(o.status);
          const next = STATUSES[idx + 1];
          return (
            <View key={o.id} style={s.orderCard}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View style={{ flex: 1 }}>
                  <Text style={type.h3}>#{o.id} · {o.customer?.name ?? 'Customer'}</Text>
                  <Text style={type.small} numberOfLines={1}>{o.customer?.address}</Text>
                </View>
                <StatusPill status={o.status} />
              </View>

              <View style={{ marginTop: 8, gap: 3 }}>
                {o.lines.map((l) => (
                  <Text key={l.id} style={type.body}>
                    {l.emoji} {l.name}  <Text style={{ fontWeight: '800' }}>×{l.qty}</Text>
                  </Text>
                ))}
              </View>
              <Text style={[type.small, { marginTop: 6 }]}>Bill: ₹{o.bill.total} (incl. GST & delivery)</Text>

              {next && (
                <TouchableOpacity style={s.advanceBtn} onPress={() => advanceOrder(o.id)} activeOpacity={0.85}>
                  <Text style={s.advanceText}>Mark as {next} →</Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}

        {/* ---- Menu availability ---- */}
        <Text style={[type.h2, { marginTop: spacing.l }]}>Menu availability</Text>
        <Text style={[type.small, { marginBottom: spacing.s }]}>
          Toggle an item off and customers instantly see it as sold out.
        </Text>
        {MENU.map((m) => {
          const sold = isSoldOut(m.id);
          return (
            <View key={m.id} style={s.availRow}>
              <Text style={{ fontSize: 18 }}>{m.emoji}</Text>
              <VegMark veg={m.veg} />
              <Text style={[type.body, { flex: 1, fontWeight: '600' }, sold && { color: colors.muted, textDecorationLine: 'line-through' }]} numberOfLines={1}>
                {m.name}
              </Text>
              <Switch
                value={!sold}
                onValueChange={() => toggleSoldOut(m.id)}
                trackColor={{ false: '#E5D5CB', true: '#CBE5D2' }}
                thumbColor={sold ? colors.nonveg : colors.success}
              />
            </View>
          );
        })}

        {/* ---- Delivered ---- */}
        {done.length > 0 && (
          <>
            <Text style={[type.h2, { marginTop: spacing.l }]}>Delivered</Text>
            {done.map((o) => (
              <View key={o.id} style={[s.orderCard, { opacity: 0.6 }]}>
                <Text style={type.h3}>#{o.id} · ₹{o.bill.total}</Text>
                <Text style={type.small}>
                  {o.lines.reduce((n, l) => n + l.qty, 0)} items · delivered{' '}
                  {new Date(o.timeline[o.timeline.length - 1].at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            ))}
          </>
        )}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  lockWrap: {
    flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center',
    padding: spacing.l, gap: spacing.s,
  },
  pinInput: {
    alignSelf: 'stretch', backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.line,
    borderRadius: radius.m, padding: 14, fontSize: 18, color: colors.ink, textAlign: 'center',
    letterSpacing: 6, marginTop: spacing.m,
  },
  header: { backgroundColor: colors.dark, paddingTop: 56, paddingBottom: spacing.m, paddingHorizontal: spacing.m },
  headTitle: { fontSize: 20, fontWeight: '800', color: '#fff' },
  headSub: { color: '#C7B8AC', fontSize: 12.5, marginTop: 2 },
  lockBtn: { borderWidth: 1, borderColor: '#4A3C32', borderRadius: radius.s, paddingVertical: 4, paddingHorizontal: 10 },
  autoRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginTop: spacing.m, gap: spacing.s,
  },
  orderCard: {
    backgroundColor: colors.surface, borderRadius: radius.l, borderWidth: 1, borderColor: colors.line,
    padding: spacing.l, marginTop: spacing.m,
  },
  advanceBtn: {
    marginTop: spacing.m, backgroundColor: colors.primary, borderRadius: radius.m,
    paddingVertical: 12, alignItems: 'center',
  },
  advanceText: { color: '#fff', fontWeight: '800', fontSize: 14 },
  availRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderRadius: radius.m, borderWidth: 1, borderColor: colors.line,
    paddingVertical: 8, paddingHorizontal: spacing.m, marginBottom: spacing.s,
  },
});
