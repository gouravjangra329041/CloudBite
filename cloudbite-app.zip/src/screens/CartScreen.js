import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, StyleSheet, Alert } from 'react-native';
import { useKitchen } from '../context/KitchenContext';
import { Stepper, PrimaryButton, VegMark } from '../components/ui';
import { FREE_DELIVERY_ABOVE } from '../data/menu';
import { colors, spacing, radius, type } from '../theme';

export default function CartScreen({ navigation }) {
  const { cartLines, cart, add, remove, bill, placeOrder } = useKitchen();
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');

  const checkout = () => {
    if (!name.trim() || !address.trim()) {
      Alert.alert('Almost there', 'Please enter your name and delivery address.');
      return;
    }
    const id = placeOrder({ name: name.trim(), address: address.trim() });
    if (id) {
      Alert.alert('Order placed! 🎉', `Your order ${id} has reached our kitchen. Track it live in the Orders tab.`);
      navigation.navigate('Orders');
    }
  };

  if (cartLines.length === 0) {
    return (
      <View style={s.empty}>
        <Text style={{ fontSize: 52 }}>🛒</Text>
        <Text style={type.h2}>Your cart is empty</Text>
        <Text style={[type.small, { textAlign: 'center', marginTop: 4 }]}>
          Head to the Menu and add something delicious.
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ padding: spacing.m, paddingTop: 60, paddingBottom: 40 }}>
      <Text style={type.h1}>Your cart</Text>

      {/* Line items */}
      <View style={{ marginTop: spacing.m, gap: spacing.s }}>
        {cartLines.map(({ item, qty }) => (
          <View key={item.id} style={s.line}>
            <Text style={{ fontSize: 22 }}>{item.emoji}</Text>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <VegMark veg={item.veg} />
                <Text style={type.h3} numberOfLines={1}>{item.name}</Text>
              </View>
              <Text style={type.small}>₹{item.price} each</Text>
            </View>
            <Stepper qty={qty} onAdd={() => add(item.id)} onRemove={() => remove(item.id)} />
            <Text style={s.lineTotal}>₹{item.price * qty}</Text>
          </View>
        ))}
      </View>

      {/* Bill summary */}
      <View style={s.billCard}>
        <Text style={type.label}>Bill summary</Text>
        {[
          ['Item subtotal', `₹${bill.subtotal}`],
          ['GST (5%)', `₹${bill.gst}`],
          ['Delivery fee', bill.delivery === 0 ? 'FREE' : `₹${bill.delivery}`],
        ].map(([k, v]) => (
          <View key={k} style={s.billRow}>
            <Text style={type.body}>{k}</Text>
            <Text style={[type.body, v === 'FREE' && { color: colors.success, fontWeight: '800' }]}>{v}</Text>
          </View>
        ))}
        {bill.delivery > 0 && (
          <Text style={[type.small, { marginTop: 2 }]}>
            Add ₹{FREE_DELIVERY_ABOVE - bill.subtotal} more for free delivery
          </Text>
        )}
        <View style={s.divider} />
        <View style={s.billRow}>
          <Text style={[type.h3]}>To pay</Text>
          <Text style={[type.h2, { color: colors.primary }]}>₹{bill.total}</Text>
        </View>
      </View>

      {/* Delivery details */}
      <Text style={[type.label, { marginTop: spacing.l, marginBottom: spacing.s }]}>Delivery details</Text>
      <TextInput
        style={s.input} placeholder="Your name" placeholderTextColor={colors.muted}
        value={name} onChangeText={setName}
      />
      <TextInput
        style={[s.input, { minHeight: 64, textAlignVertical: 'top' }]}
        placeholder="Delivery address" placeholderTextColor={colors.muted}
        value={address} onChangeText={setAddress} multiline
      />

      <PrimaryButton title={`Place order · ₹${bill.total}`} onPress={checkout} style={{ marginTop: spacing.m }} />
      <Text style={[type.small, { textAlign: 'center', marginTop: spacing.s }]}>
        Demo checkout — no real payment is taken.
      </Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  empty: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: spacing.l, gap: 6 },
  line: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.s,
    backgroundColor: colors.surface, borderRadius: radius.m, borderWidth: 1, borderColor: colors.line,
    padding: spacing.m,
  },
  lineTotal: { fontWeight: '800', color: colors.ink, minWidth: 52, textAlign: 'right' },
  billCard: {
    backgroundColor: colors.surface, borderRadius: radius.l, borderWidth: 1, borderColor: colors.line,
    padding: spacing.l, marginTop: spacing.l, gap: 8,
  },
  billRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' },
  divider: { height: 1, backgroundColor: colors.line, marginVertical: 4 },
  input: {
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line,
    borderRadius: radius.m, padding: 13, fontSize: 15, color: colors.ink, marginBottom: spacing.s,
  },
});
