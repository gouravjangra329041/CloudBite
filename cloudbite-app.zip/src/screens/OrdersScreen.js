import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { useKitchen, STATUSES } from '../context/KitchenContext';
import { Timeline, StatusPill } from '../components/ui';
import { colors, spacing, radius, type } from '../theme';

export default function OrdersScreen() {
  const { orders } = useKitchen();

  if (orders.length === 0) {
    return (
      <View style={s.empty}>
        <Text style={{ fontSize: 52 }}>🧾</Text>
        <Text style={type.h2}>No orders yet</Text>
        <Text style={[type.small, { textAlign: 'center', marginTop: 4 }]}>
          Once you place an order, you can track it live here.
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: spacing.m, paddingTop: 60, paddingBottom: 40 }}
      data={orders}
      keyExtractor={(o) => o.id}
      ListHeaderComponent={<Text style={[type.h1, { marginBottom: spacing.m }]}>Your orders</Text>}
      renderItem={({ item: o }) => {
        const active = o.status !== 'Delivered';
        const stepsDone = STATUSES.indexOf(o.status);
        return (
          <View style={s.card}>
            <View style={s.headRow}>
              <View>
                <Text style={type.h3}>Order {o.id}</Text>
                <Text style={type.small}>
                  {new Date(o.placedAt).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  {'  ·  ₹'}{o.bill.total}
                </Text>
              </View>
              <StatusPill status={o.status} />
            </View>

            <Text style={[type.small, { marginTop: 6 }]} numberOfLines={2}>
              {o.lines.map((l) => `${l.emoji} ${l.name} ×${l.qty}`).join('  ·  ')}
            </Text>

            {active && (
              <Text style={s.eta}>
                ⏱ Estimated delivery ~{o.etaMins} min from order · step {stepsDone + 1} of {STATUSES.length}
              </Text>
            )}

            <Timeline order={o} />
          </View>
        );
      }}
    />
  );
}

const s = StyleSheet.create({
  empty: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: spacing.l, gap: 6 },
  card: {
    backgroundColor: colors.surface, borderRadius: radius.l, borderWidth: 1, borderColor: colors.line,
    padding: spacing.l, marginBottom: spacing.m,
  },
  headRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: spacing.s },
  eta: { ...type.small, color: '#9A6A1D', fontWeight: '700', marginTop: 8 },
});
