// CloudBite — cloud kitchen menu (edit freely: it's just data).
// spice: 0 none · 1 mild · 2 medium · 3 hot

export const CATEGORIES = ['All', 'Biryani & Rice', 'Burgers & Wraps', 'Curries & Thali', 'Desserts & Drinks'];

export const MENU = [
  // ---- Biryani & Rice ----
  { id: 'm1', name: 'Hyderabadi Chicken Biryani', cat: 'Biryani & Rice', emoji: '🍗', veg: false, price: 249, prepMins: 25, spice: 3,
    desc: 'Slow-cooked basmati layered with marinated chicken, saffron and fried onions. Served with raita.' },
  { id: 'm2', name: 'Veg Dum Biryani', cat: 'Biryani & Rice', emoji: '🍚', veg: true, price: 199, prepMins: 22, spice: 2,
    desc: 'Garden vegetables and basmati sealed and steamed with mint, saffron and whole spices.' },
  { id: 'm3', name: 'Paneer Tikka Rice Bowl', cat: 'Biryani & Rice', emoji: '🥘', veg: true, price: 219, prepMins: 18, spice: 2,
    desc: 'Char-grilled paneer tikka on jeera rice with mint chutney drizzle.' },
  // ---- Burgers & Wraps ----
  { id: 'm4', name: 'Classic Chicken Burger', cat: 'Burgers & Wraps', emoji: '🍔', veg: false, price: 179, prepMins: 15, spice: 1,
    desc: 'Crispy fried chicken, house mayo, lettuce and pickles in a toasted brioche bun.' },
  { id: 'm5', name: 'Aloo Tikki Burger', cat: 'Burgers & Wraps', emoji: '🥔', veg: true, price: 129, prepMins: 12, spice: 1,
    desc: 'Spiced potato patty, tangy tamarind sauce, onions and fresh salad.' },
  { id: 'm6', name: 'Paneer Kathi Roll', cat: 'Burgers & Wraps', emoji: '🌯', veg: true, price: 159, prepMins: 14, spice: 2,
    desc: 'Flaky paratha rolled with masala paneer, onions and green chutney.' },
  { id: 'm7', name: 'Chicken Shawarma Wrap', cat: 'Burgers & Wraps', emoji: '🌮', veg: false, price: 189, prepMins: 15, spice: 2,
    desc: 'Garlic-marinated chicken, pickled veg and tahini in a warm pita wrap.' },
  // ---- Curries & Thali ----
  { id: 'm8', name: 'Butter Chicken + 2 Naan', cat: 'Curries & Thali', emoji: '🍛', veg: false, price: 299, prepMins: 24, spice: 2,
    desc: 'Creamy tomato-makhani chicken with two butter naans.' },
  { id: 'm9', name: 'Dal Makhani + Rice', cat: 'Curries & Thali', emoji: '🫘', veg: true, price: 189, prepMins: 20, spice: 1,
    desc: 'Overnight-simmered black lentils finished with cream, served with steamed rice.' },
  { id: 'm10', name: 'Mini Veg Thali', cat: 'Curries & Thali', emoji: '🍱', veg: true, price: 229, prepMins: 22, spice: 2,
    desc: 'Paneer curry, dal, rice, 2 rotis, salad and a sweet — a complete meal.' },
  { id: 'm14', name: 'Paneer Butter Masala + 2 Naan', cat: 'Curries & Thali', emoji: '🧈', veg: true, price: 259, prepMins: 22, spice: 2,
    desc: 'Cottage cheese simmered in silky tomato-butter gravy with two naans.' },
  { id: 'm15', name: 'Chole Bhature', cat: 'Curries & Thali', emoji: '🫓', veg: true, price: 169, prepMins: 18, spice: 2,
    desc: 'Spicy Punjabi chickpeas with two fluffy fried bhature and pickled onions.' },
  { id: 'm16', name: 'Rajma Chawal Bowl', cat: 'Biryani & Rice', emoji: '🍲', veg: true, price: 159, prepMins: 16, spice: 1,
    desc: 'Comforting kidney-bean curry over steamed rice, home-style.' },
  { id: 'm17', name: 'Veg Hakka Noodles', cat: 'Burgers & Wraps', emoji: '🍜', veg: true, price: 149, prepMins: 14, spice: 2,
    desc: 'Wok-tossed noodles with crunchy vegetables and soy-garlic sauce.' },
  { id: 'm18', name: 'Crispy Corn Chaat', cat: 'Burgers & Wraps', emoji: '🌽', veg: true, price: 119, prepMins: 10, spice: 2,
    desc: 'Golden fried corn tossed with onions, lime and chaat masala.' },
  // ---- Desserts & Drinks ----
  { id: 'm11', name: 'Gulab Jamun (2 pc)', cat: 'Desserts & Drinks', emoji: '🍮', veg: true, price: 79, prepMins: 5, spice: 0,
    desc: 'Soft khoya dumplings soaked in warm rose-cardamom syrup.' },
  { id: 'm12', name: 'Cold Coffee Shake', cat: 'Desserts & Drinks', emoji: '🥤', veg: true, price: 99, prepMins: 6, spice: 0,
    desc: 'Thick blended coffee shake topped with a cocoa dusting.' },
  { id: 'm13', name: 'Masala Lemonade', cat: 'Desserts & Drinks', emoji: '🍋', veg: true, price: 69, prepMins: 4, spice: 1,
    desc: 'Fresh lime with a chaat-masala kick, served ice-cold.' },
];

export const GST_RATE = 0.05;          // 5%
export const DELIVERY_FEE = 30;        // flat, in ₹
export const FREE_DELIVERY_ABOVE = 500;
