import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MENU, GST_RATE, DELIVERY_FEE, FREE_DELIVERY_ABOVE } from '../data/menu';

// The order lifecycle is a simple state machine — one source of truth
// shared by the customer's tracking timeline and the kitchen's queue.
export const STATUSES = ['Placed', 'Accepted', 'Preparing', 'Ready', 'Out for delivery', 'Delivered'];

const KEY = 'cloudbite-state-v1';
const AUTO_ADVANCE_MS = 25000; // demo mode: orders progress every 25 s

const Ctx = createContext(null);
export const useKitchen = () => useContext(Ctx);

export function KitchenProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [cart, setCart] = useState({});        // { itemId: qty }
  const [orders, setOrders] = useState([]);    // newest first
  const [soldOut, setSoldOut] = useState([]);  // [itemId]
  const [autoMode, setAutoMode] = useState(false); // owner-controlled; OFF by default
  const [ownerMode, setOwnerMode] = useState(false);   // unlocked per session with the owner PIN
  const stateRef = useRef({});

  // ---- load / persist ----
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (raw) {
          const s = JSON.parse(raw);
          setCart(s.cart ?? {});
          setOrders(s.orders ?? []);
          setSoldOut(s.soldOut ?? []);
          setAutoMode(s.autoMode ?? false);
        }
      } catch {}
      setReady(true);
    })();
  }, []);

  useEffect(() => {
    stateRef.current = { cart, orders, soldOut, autoMode };
    if (ready) AsyncStorage.setItem(KEY, JSON.stringify(stateRef.current)).catch(() => {});
  }, [cart, orders, soldOut, autoMode, ready]);

  // ---- demo auto-progression (kitchen can switch it off) ----
  useEffect(() => {
    if (!autoMode) return;
    const t = setInterval(() => {
      setOrders((prev) =>
        prev.map((o) => {
          const i = STATUSES.indexOf(o.status);
          if (i < 0 || i >= STATUSES.length - 1) return o;
          const due = Date.now() - new Date(o.timeline[o.timeline.length - 1].at).getTime() > AUTO_ADVANCE_MS;
          if (!due) return o;
          const next = STATUSES[i + 1];
          return { ...o, status: next, timeline: [...o.timeline, { status: next, at: new Date().toISOString() }] };
        })
      );
    }, 5000);
    return () => clearInterval(t);
  }, [autoMode]);

  // ---- cart ----
  const itemById = (id) => MENU.find((m) => m.id === id);
  const add = (id) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const remove = (id) =>
    setCart((c) => {
      const q = (c[id] ?? 0) - 1;
      const n = { ...c };
      if (q <= 0) delete n[id];
      else n[id] = q;
      return n;
    });
  const clearCart = () => setCart({});

  const cartLines = Object.entries(cart)
    .map(([id, qty]) => ({ item: itemById(id), qty }))
    .filter((l) => l.item);
  const cartCount = cartLines.reduce((s, l) => s + l.qty, 0);

  const bill = (() => {
    const subtotal = cartLines.reduce((s, l) => s + l.item.price * l.qty, 0);
    const gst = Math.round(subtotal * GST_RATE);
    const delivery = subtotal === 0 || subtotal >= FREE_DELIVERY_ABOVE ? 0 : DELIVERY_FEE;
    return { subtotal, gst, delivery, total: subtotal + gst + delivery };
  })();

  // ---- orders ----
  const placeOrder = (customer) => {
    if (cartLines.length === 0) return null;
    const now = new Date().toISOString();
    const order = {
      id: 'CB' + String(Date.now()).slice(-6),
      customer, // { name, address }
      lines: cartLines.map((l) => ({ id: l.item.id, name: l.item.name, emoji: l.item.emoji, price: l.item.price, qty: l.qty })),
      bill,
      status: 'Placed',
      timeline: [{ status: 'Placed', at: now }],
      placedAt: now,
      etaMins: Math.max(...cartLines.map((l) => l.item.prepMins)) + 20,
    };
    setOrders((prev) => [order, ...prev]);
    clearCart();
    return order.id;
  };

  const advanceOrder = (id) =>
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o;
        const i = STATUSES.indexOf(o.status);
        if (i >= STATUSES.length - 1) return o;
        const next = STATUSES[i + 1];
        return { ...o, status: next, timeline: [...o.timeline, { status: next, at: new Date().toISOString() }] };
      })
    );

  // ---- owner access (order-status control is owner-only) ----
  const OWNER_PIN = '1234'; // demo PIN — change before a real deployment
  const unlockOwner = (pin) => {
    const ok = pin === OWNER_PIN;
    if (ok) setOwnerMode(true);
    return ok;
  };
  const lockOwner = () => setOwnerMode(false);

  // ---- menu availability ----
  const isSoldOut = (id) => soldOut.includes(id);
  const toggleSoldOut = (id) =>
    setSoldOut((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  return (
    <Ctx.Provider
      value={{
        ready, cart, cartLines, cartCount, bill, add, remove, clearCart,
        orders, placeOrder, advanceOrder,
        soldOut, isSoldOut, toggleSoldOut,
        autoMode, setAutoMode,
        ownerMode, unlockOwner, lockOwner,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
