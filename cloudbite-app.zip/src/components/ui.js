import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, radius, spacing, type } from '../theme';
import { STATUSES } from '../context/KitchenContext';

// ---- Veg / non-veg indicator (the little square badge) ----
export function VegMark({ veg }) {
  const c = veg ? colors.veg : colors.nonveg;
  return (
    <View style={[s.vegBox, { borderColor: c }]}>
      <View style={[s.vegDot, { backgroundColor: c }]} />
    </View>
  );
}

export function SpiceMeter({ level }) {
  if (!level) return null;
  return <Text style={{ fontSize: 11 }}>{'🌶'.repeat(level)}</Text>;
}

// ---- Quantity stepper ----
export function Stepper({ qty, onAdd, onRemove, disabled }) {
  if (qty === 0) {
    return (
      <TouchableOpacity
        style={[s.addBtn, disabled && { opacity: 0.4 }]}
        onPress={onAdd}
        disabled={disabled}
        activeOpacity={0.85}
      >
        <Text style={s.addBtnText}>{disabled ? 'SOLD OUT' : 'ADD +'}</Text>
      </TouchableOpacity>
    );
  }
  return (
    <View style={s.step}>
      <TouchableOpacity style={s.stepBtn} onPress={onRemove}>
        <Text style={s.stepBtnText}>−</Text>
      </TouchableOpacity>
      <Text style={s.stepQty}>{qty}</Text>
      <TouchableOpacity style={s.stepBtn} onPress={onAdd} disabled={disabled}>
        <Text style={[s.stepBtnText, disabled && { opacity: 0.4 }]}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

export function Chip({ label, active, onPress }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[s.chip, active && { backgroundColor: colors.primary, borderColor: colors.primary }]}
    >
      <Text style={[s.chipText, active && { color: '#fff' }]}>{label}</Text>
    </TouchableOpacity>
  );
}

export function PrimaryButton({ title, onPress, style, disabled }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[s.btn, disabled && { opacity: 0.5 }, style]}
      activeOpacity={0.85}
    >
      <Text style={s.btnText}>{title}</Text>
    </TouchableOpacity>
  );
}

export function StatusPill({ status }) {
  const done = status === 'Delivered';
  return (
    <View style={[s.pill, { backgroundColor: done ? '#E7F4EC' : colors.accentSoft }]}>
      <Text style={[s.pillText, { color: done ? colors.success : '#9A6A1D' }]}>{status}</Text>
    </View>
  );
}

// ---- Order status timeline (the tracking spine) ----
export function Timeline({ order }) {
  const currentIdx = STATUSES.indexOf(order.status);
  return (
    <View style={{ marginTop: spacing.s }}>
      {STATUSES.map((st, i) => {
        const done = i < currentIdx;
        const current = i === currentIdx;
        const stamp = order.timeline.find((t) => t.status === st);
        return (
          <View key={st} style={s.tlRow}>
            <View style={{ alignItems: 'center', width: 22 }}>
              <View
                style={[
                  s.tlDot,
                  done && { backgroundColor: colors.success, borderColor: colors.success },
                  current && { backgroundColor: colors.primary, borderColor: colors.primary },
                ]}
              >
                {done && <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800' }}>✓</Text>}
              </View>
              {i < STATUSES.length - 1 && (
                <View style={[s.tlLine, done && { backgroundColor: colors.success }]} />
              )}
            </View>
            <View style={{ flex: 1, paddingBottom: i < STATUSES.length - 1 ? 12 : 0 }}>
              <Text
                style={[
                  type.body,
                  { fontWeight: current ? '800' : done ? '700' : '500' },
                  !done && !current && { color: colors.muted },
                ]}
              >
                {st}
              </Text>
              {stamp && (
                <Text style={type.small}>
                  {new Date(stamp.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              )}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const s = StyleSheet.create({
  vegBox: { width: 16, height: 16, borderWidth: 1.5, borderRadius: 3, alignItems: 'center', justifyContent: 'center' },
  vegDot: { width: 7, height: 7, borderRadius: 4 },
  addBtn: {
    borderWidth: 1.5, borderColor: colors.primary, borderRadius: radius.s,
    paddingVertical: 7, paddingHorizontal: 14, backgroundColor: colors.surface,
  },
  addBtnText: { color: colors.primary, fontWeight: '800', fontSize: 12 },
  step: {
    flexDirection: 'row', alignItems: 'center', borderRadius: radius.s,
    backgroundColor: colors.primary, overflow: 'hidden',
  },
  stepBtn: { paddingVertical: 6, paddingHorizontal: 12 },
  stepBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  stepQty: { color: '#fff', fontWeight: '800', fontSize: 14, minWidth: 20, textAlign: 'center' },
  chip: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.pill,
    borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface, marginRight: 8,
  },
  chipText: { fontSize: 13, fontWeight: '600', color: colors.ink },
  btn: { backgroundColor: colors.primary, paddingVertical: 14, borderRadius: radius.m, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '800', fontSize: 15 },
  pill: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill },
  pillText: { fontSize: 11.5, fontWeight: '800' },
  tlRow: { flexDirection: 'row', gap: 10 },
  tlDot: {
    width: 16, height: 16, borderRadius: 8, borderWidth: 2, borderColor: colors.line,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  tlLine: { width: 2, flex: 1, backgroundColor: colors.line, marginVertical: 2, minHeight: 14 },
});
