import React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';

import { KitchenProvider, useKitchen } from './src/context/KitchenContext';
import { colors } from './src/theme';

import MenuScreen from './src/screens/MenuScreen';
import CartScreen from './src/screens/CartScreen';
import OrdersScreen from './src/screens/OrdersScreen';
import KitchenScreen from './src/screens/KitchenScreen';

const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: colors.bg, primary: colors.primary },
};

const tabIcon = (emoji) => ({ focused }) => (
  <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.45 }}>{emoji}</Text>
);

function CartBadgeIcon({ focused }) {
  const { cartCount } = useKitchen();
  return (
    <View>
      <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.45 }}>🛒</Text>
      {cartCount > 0 && (
        <View style={{
          position: 'absolute', top: -4, right: -10, backgroundColor: colors.primary,
          borderRadius: 9, minWidth: 17, height: 17, alignItems: 'center', justifyContent: 'center',
          paddingHorizontal: 3,
        }}>
          <Text style={{ color: '#fff', fontSize: 10, fontWeight: '800' }}>{cartCount}</Text>
        </View>
      )}
    </View>
  );
}

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.line, height: 60, paddingBottom: 6 },
      }}
    >
      <Tab.Screen name="Menu" component={MenuScreen} options={{ tabBarIcon: tabIcon('🍽') }} />
      <Tab.Screen name="Cart" component={CartScreen} options={{ tabBarIcon: (p) => <CartBadgeIcon {...p} /> }} />
      <Tab.Screen name="Orders" component={OrdersScreen} options={{ tabBarIcon: tabIcon('🧾') }} />
      <Tab.Screen name="Owner" component={KitchenScreen} options={{ tabBarIcon: tabIcon('🔐') }} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <KitchenProvider>
      <NavigationContainer theme={navTheme}>
        <StatusBar style="light" />
        <Tabs />
      </NavigationContainer>
    </KitchenProvider>
  );
}
